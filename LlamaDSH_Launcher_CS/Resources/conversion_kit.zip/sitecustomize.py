# LlamaDSH Launcher compat shim: pip gguf may lag behind the conversion package.
# Missing enum members are only referenced by unused model classes at import time,
# so a dummy value is safe; members actually used by the target model exist for real.
try:
    import gguf as _gguf_mod

    class _FlexibleEnum:
        def __init__(self, real):
            object.__setattr__(self, "_real", real)

        def __getattr__(self, name):
            try:
                return getattr(object.__getattribute__(self, "_real"), name)
            except AttributeError:
                return 0

    _gguf_mod.MODEL_ARCH = _FlexibleEnum(_gguf_mod.MODEL_ARCH)
    _gguf_mod.MODEL_TENSOR = _FlexibleEnum(_gguf_mod.MODEL_TENSOR)
except Exception:
    pass
